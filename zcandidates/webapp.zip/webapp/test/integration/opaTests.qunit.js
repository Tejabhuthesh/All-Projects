/* global QUnit */

sap.ui.require(["candidate/deatails/zcandidates/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
